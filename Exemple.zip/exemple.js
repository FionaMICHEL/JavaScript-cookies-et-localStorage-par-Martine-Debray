window.onload = function() {

    // pace un écouteur d'évènement sur les boutons des différentes sections //
    let st2 = document.querySelector('#star-loc');
    st2.addEventListener('click', starlocalstorage); 

    let ev1 = document.querySelector('#loc');
    ev1.addEventListener('click', loc);
    let ev2 = document.querySelector('#sess');
    ev2.addEventListener('click', sess);
    let ev3 = document.querySelector('#cook');
    ev3.addEventListener('click', cook);

}

function starlocalstorage() {
    //La fonction suivante récupère trois élément du stockage local, 
    //puis réutilise les valeurs renvoyés afin de modifier le style de la page .
    var currentColor = localStorage.getItem('bgcolor');
    var currentFont = localStorage.getItem('font');
    var currentImage = localStorage.getItem('image');

    document.getElementById('bgcolor').style.backgroundColor = currentColor;
    document.getElementById('font').value = currentFont;
    document.getElementById('image').value = currentImage;

    //htmlElem.style.backgroundColor = '#' + currentColor;
    //pElem.style.fontFamily = currentFont;
    //imgElem.setAttribute('src', currentImage);
}

function loc(){
    //localStorage.setItem('DVD Star Trek' , '9.99');
    localStorage.setItem('bgcolor', 'blue');
    //localStorage.getItem();
    //localStorage.removeItem();
    //localStorage.clear();

    alert(sessionStorage.getItem());
}

function sess(){
    sessionStorage.setItem('user="yoda"', 'password="azerty');
    //sessionStorage.getItem();
    //sessionStorage.removeItem();
    //sessionStorage.clear();

    alert(sessionStorage.getItem());
}

function cook(){
    //document.cookie = 'user=Spock'; //crée ou modifie un cookie
    
    //document.cookie = 'user=Spock; path=/'; //ce cookies est accessible à toutes les pages

    //document.cookie = 'user=Spock; path=/entreprise'; //ce cookies est accessible 
    //à toutes les pages /entreprise et /entreprise/..

    document.cookie = 'user=Spock; path=/; domain=StarTrek.com'; //ce cookies est disponible
    // pour le dommaine StarTrek.com et l'ensemble des sous domaines de StarTrek.com

    
    //let date = new date(Date.now() + 86400000); //86400000ms = 1 jour
    //date = date.toUTCString();
    //crée ou met à jour un cookie 'user' qui expire 20 heures après sa création
    //document.cookie = 'user=Spock; path=/; domain=StarTrek.com expire=' + date;

    //version alternative de la création ou mise à jour du cookie 'user' 
    //qui expire 20 heures après sa création
    //document.cookie = 'user=Spock; path=/; domain=StarTrek.com max-age= 86400';

    //ce cookie est envoyer uniquement par HTTPS et non par HTTP
    //document.cookie = 'user=Spock; path=/; domain=StarTrek.com max-age= 86400; secure';


    alert(document.cookies); //afiche la liste des cookies
}
